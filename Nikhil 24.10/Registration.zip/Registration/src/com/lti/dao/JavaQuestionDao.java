package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.JavaQuestion;

@Repository
public class JavaQuestionDao{
	int count=0;
	int no=0,marks;
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void save(JavaQuestion questions) {
		// TODO Auto-generated method stub
		entityManager.merge(questions);
		
	}
	
	
	public JavaQuestion fetch(int id) {
		String ql= "select j from JavaQuestion j where j.id= :id";
		Query q = entityManager.createQuery(ql);
		q.setParameter("id", id);
	return (JavaQuestion)q.getSingleResult();
	}


	public int calc(int id, String opt) {
		no++;
		String ql="select j.correctans from JavaQuestion j where j.id= :id"; 
		Query q = entityManager.createQuery(ql);
		q.setParameter("id", id);
		String answerDao=(String)q.getSingleResult();
		System.out.println("yeh answerdao hai"+answerDao);
		System.out.println("yeh opt hai"+opt);
		
		if(opt.equals(answerDao))
		{
			count++;
			System.out.println("inside outer if "+count);
		}
		if(no==10) {
			
			System.out.println("inside inner if "+count);
			return count;
		
		}
		else {
		return 0;
	}
	}

	







	
/*	public List<Question> fetchAll() {
		String ql = "select q from Question q";
		Query query = entityManager.createQuery(ql);
		return q.getResultList();
	}*/
	
	/*public int getNextId() {
		Query qry= entityManager.createQuery("select max(id) from Student");
		int id= (Integer) qry.getSingleResult();
		return id+1;
	}*/
}


