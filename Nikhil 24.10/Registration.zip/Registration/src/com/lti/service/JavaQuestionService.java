package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.JavaQuestionDao;
import com.lti.entity.JavaQuestion;

@Service
public class JavaQuestionService {

	@Autowired
	private JavaQuestionDao javaquestionDao;
	
	public void questnNo(JavaQuestion questions) {
		javaquestionDao.save(questions);
		}
	
	public JavaQuestion get(int id) {
		return javaquestionDao.fetch(id);
	}

	public int calc(int qnno, String opt) {
		return javaquestionDao.calc(qnno, opt);
	}

}

