package com.lti.controller;

import java.util.Map;
import javax.annotation.Resource;
import javax.persistence.Entity;

import org.apache.jasper.tagplugins.jstl.core.Out;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.dao.JavaQuestionDao;

import com.lti.entity.JavaQuestion;
import com.lti.entity.Student;
import com.lti.service.StudentService;

import com.lti.service.JavaQuestionService;

@Controller
public class StudentController {
int qnno=0;
	@Resource
	private StudentService studentService;
	@Resource
	private JavaQuestionService javaquestionService;
/*	@Resource
	private CssQuestionService cssquestionService;*/
	
	@RequestMapping(path = "/registration.lti")
	//public String register(HttpServletRequest request) {
	//public String register(@RequestParam("name") String name, @RequestParam("email") String email, ...) {
	public String registration(Student student) {
		studentService.registration(student);
		return "confirmation.jsp";
	}
	
	@RequestMapping(path = "/login.lti")
	//public String register(HttpServletRequest request) {
	//public String register(@RequestParam("name") String name, @RequestParam("email") String email, ...) {
	public String registration(@RequestParam("email") String email, @RequestParam("password") String password,  Map model) {
		Student student = studentService.get(email,password);
		model.put("student", student);
		//System.out.println(student);
		return "profile.jsp";
	}
	
	/*@RequestMapping(path = "/test.lti")
	//public String register(HttpServletRequest request) {
	//public String register(@RequestParam("name") String name, @RequestParam("email") String email, ...) {
	public String questnNo(@RequestParam("id") String qnNo,  Map model) {
		Question question = questionService.get(qnNo);
		model.put("question", question);
		//System.out.println(student);
		return "profile.jsp";*/
	
/*		@RequestMapping(path = "/test1.lti")
		//public String register(HttpServletRequest request) {
		//public String register(@RequestParam("name") String name, @RequestParam("email") String email, ...) {
		public String questnNo(@RequestParam("number") int id,  Map model) {
			//return questionService.get(id);
			Question question= questionService.get(id);
		    model.put("question", question);
		     return "confirmation.jsp";
			//System.out.println("hi");
			//return questionService.get(qnNo);
		}*/
		
		  @RequestMapping(path="/java.lti")
		  public String questnNo(@RequestParam("butn") String butn, Map model) {
			  	qnno++;
				JavaQuestion questions= javaquestionService.get(qnno);
			    model.put("question", questions);
			    /*model.put("obj", obj);*/
			    return "test.jsp";
		  	}
		  
		  @RequestMapping(path="/test.lti")
		  public String questnNo(@RequestParam("butn") String butn,@RequestParam("opt") String opt, Map model,ModelMap ans) {
			    int answer=(Integer)javaquestionService.calc(qnno,opt);
			    String count=""+answer;
			    
			  	qnno++;
				JavaQuestion questions= javaquestionService.get(qnno);
			    model.put("question", questions);
			    ans.addAttribute("count",count);
			    if(qnno<=10)
			    return "test.jsp";
			    else {
			      	if(answer>6)
			    	return "score.jsp";
			   	   	else
		    	return "profile2.jsp";
			    }
	    }
		  
/*		  @RequestMapping(path="/css.lti")
		  public String questnNos(@RequestParam("butn") String butn, Map model) {
			  	qnno++;
				CssQuestion questions= cssquestionService.get(qnno);
			    model.put("question", questions);
			    model.put("obj", obj);
			    return "test.jsp";
		  	}
		  
		  @RequestMapping(path="/test1.lti")
		  public String questnNos(@RequestParam("butn") String butn,@RequestParam("opt") String opt, Map model,ModelMap ans) {
			    int answer=(Integer)cssquestionService.calc(qnno,opt);
			    String count=""+answer;
			    
			  	qnno++;
				CssQuestion questions= cssquestionService.get(qnno);
			    model.put("question", questions);
			    ans.addAttribute("count",count);
			    if(qnno<=10)
			    return "test.jsp";
			    else {
			      	if(answer>6)
			    	return "score.jsp";
			   	   	else
		    	return "profile2.jsp";
			    }
	    }*/
		  
		  
		  
}
			    
    

