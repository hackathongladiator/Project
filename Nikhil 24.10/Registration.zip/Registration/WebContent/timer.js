
var tim; 

    var min = 10;
    var sec = 30;
    var f = new Date();
    function timer() {
      if (parseInt(sec) > -1) {

        document.getElementById("showtime").innerHTML = "Time left:   " +min + ":" + sec;
        sec = parseInt(sec) - 1;
        tim = setTimeout("timer()", 1000);
      }
      else {
          if (parseInt(sec) == 0) {
          min = parseInt(min) - 1;
          if (parseInt(min) == 0) {            
            clearTimeout(tim);
          }
          else {
            sec = 19;
            document.getElementById("showtime").innerHTML = "Time left:   " +min + ":" + sec;
            tim = setTimeout("timer()", 1000);
          }
        }

      }
    }
